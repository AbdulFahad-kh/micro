import os
import subprocess

def main():
    os.environ['DATABASE'] = 'mysql+pymysql://library-spring-user:library-secret@localhost/library'
    subprocess.run(['python', 'waitress-server.py'], cwd=os.path.dirname(os.path.abspath(__file__)))

if __name__ == '__main__':
    main()
